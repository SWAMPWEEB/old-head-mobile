# Old Head App

This repository contains a production‑ready React Native application that implements the core of the **Old Head** mobile experience.  The app is designed to help hunters and anglers in the United States plan trips, track conditions and collaborate with their friends.  It uses Supabase for authentication and data storage, Mapbox for mapping, various public APIs for environmental data and OpenAI for AI‑assisted suggestions.

## Features

* **Magic‑link Authentication** – users authenticate via email using Supabase Auth; no passwords are stored or required.
* **Dashboard** – shows AI‑driven suggestions for upcoming trips and a list of saved fishing or hunting locations.
* **Map Placeholder** – the original Mapbox implementation has been removed to maintain compatibility with Expo Go.  In this version a placeholder view is rendered instead.  If you wish to enable maps you can install a supported library such as `react-native-maps` or eject to the bare workflow.
* **AI Chat** – a chat interface backed by OpenAI GPT‑4o for answering questions such as “Where should I fish tomorrow?”  Messages are stored locally in component state.
* **Trip Planner** – choose your mode (fishing or hunting) and duration, then generate a detailed itinerary (placeholder alert currently).
* **Groups** – browse your groups and enter an invite code to join a new group.  Join requests are sent to a Supabase Edge Function named `join_group` (not included here).
* **Environmental Data Services** – a set of functions for retrieving weather forecasts, streamflow measurements, tide predictions and sunrise/sunset times.  These functions are ready to be wrapped by react‑query for caching and offline support.

## Getting Started

This project uses **Expo** to simplify development and distribution.  To run the application locally you need to have Node.js and the Expo CLI installed.  In this cleaned Expo version you should add your API keys directly into `app.json` (see the **Configuration** section below) – no separate `.env` file is required.

### 1. Install dependencies

```sh
npm install
```

The `package.json` lists all libraries used in this project.  If you add new modules you should run `npm install` again to update your lockfile.  Because this repository does not include node modules, you need internet access to install them.

### 2. Configuration

All required configuration values are defined directly inside `app.json` under the `expo.extra` field.  You do **not** need to create a `.env` file to run this version of the application.  Open `app.json` and replace the placeholder values with your real credentials:

```json
{
  "expo": {
    "extra": {
      "SUPABASE_URL": "https://YOUR-PROJECT.supabase.co",
      "SUPABASE_ANON_KEY": "YOUR_SUPABASE_ANON_KEY",
      "MAPBOX_TOKEN": "YOUR_MAPBOX_TOKEN",
      "OPENAI_API_KEY": "YOUR_OPENAI_API_KEY",
      "WEATHER_API_KEY": "YOUR_WEATHER_API_KEY"
    }
  }
}
```

* **SUPABASE_URL & SUPABASE_ANON_KEY** – available in your Supabase project settings.  These allow the app to read and write to your database and handle authentication.
* **MAPBOX_TOKEN** – unused in this Expo version, but kept for future bare workflow integration.
* **OPENAI_API_KEY** – used to call GPT‑4o in the AI chat and suggestion services.
* **WEATHER_API_KEY** – used to fetch weather forecasts for pin drops and trip planning.

After updating the credentials the app can run without any additional environment setup.

### 3. Prepare your Supabase schema

This app assumes the existence of several tables in your Supabase database along with appropriate Row Level Security (RLS) policies.  Create these tables by executing SQL similar to the following:

```sql
-- Users table is managed by supabase.auth.users

create table groups (
  id serial primary key,
  admin_id uuid not null references auth.users on delete cascade,
  name text not null,
  invite_code text not null
);

create table join_requests (
  id serial primary key,
  user_id uuid not null references auth.users on delete cascade,
  group_id integer not null references groups on delete cascade,
  status text not null default 'pending'
);

create table pins (
  id serial primary key,
  location geography(point, 4326) not null,
  visibility text not null,
  created_by uuid not null references auth.users on delete cascade,
  group_id integer references groups on delete cascade,
  type text not null
);

-- Additional tables: logs, comments, preferences, species as described in the
-- instructions file.  Set up RLS policies to restrict visibility to users
-- within the same group or to public pins.
```

You must also implement a **`join_group`** Supabase Edge Function which accepts an `inviteCode` and inserts a record into `join_requests`.  The Groups screen in this app calls that function when a user enters a code.

### 4. Run the app

Once dependencies and environment variables are configured, start the Expo development server:

```sh
npm start
```

You can then open the app on an Android emulator, iOS simulator or your physical device via the Expo Go app.  As you develop, the app will automatically reload when you change files.

## Notes & Next Steps

* The current implementation provides a functional skeleton that aligns with the specification in the “Old Head Agent Instructions” file.  Many features, such as offline caching with WatermelonDB, interactive pin management, real AI suggestions and detailed trip planning, are placeholders that require further development.
* To add offline support, wrap API calls with `react-query` and configure a WatermelonDB database for local persistence.  You can queue writes to Supabase when the device is offline.
* The chat and trip planning screens rely on the OpenAI API.  Be mindful of rate limits and costs when integrating these features into production.  Consider proxying requests through your own backend to enforce usage quotas.
* For maps, integrate the Mapbox SDK fully by handling long presses to create pins, displaying offline tile packs and showing user location and compass headings.  See the Mapbox React Native documentation for details.

We hope this project serves as a solid foundation for building your hunting and fishing companion app.  Tighten up the user experience, secure your API keys and extend the functionality to deliver an exceptional tool for outdoor enthusiasts.